<?php
session_start();
include 'db_connect.php';

// CSRF token generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("Invalid CSRF token.");
    }

    $name = htmlspecialchars(trim($_POST['name']));
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $phone = htmlspecialchars(trim($_POST['phone']));
    $visit_date = htmlspecialchars(trim($_POST['visit_date']));
    $visit_time = htmlspecialchars(trim($_POST['visit_time']));
    $purpose = htmlspecialchars(trim($_POST['purpose']));
    $course = htmlspecialchars(trim($_POST['course']));

    if (!$email) {
        die("Invalid email.");
    }

    $stmt = $conn->prepare("INSERT INTO booking (name, email, phone, visit_date, visit_time, purpose, course) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $name, $email, $phone, $visit_date, $visit_time, $purpose, $course);
    $stmt->execute();

    echo "Booking successful.";
}
?>

<!-- Booking form -->
<form method="post">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    Name: <input type="text" name="name" required><br>
    Email: <input type="email" name="email" required><br>
    Phone: <input type="text" name="phone" required><br>
    Date: <input type="date" name="visit_date" required><br>
    Time: <input type="time" name="visit_time" required><br>
    Purpose: <input type="text" name="purpose" required><br>
    Course: <input type="text" name="course" required><br>
    <button type="submit">Book Visit</button>
</form>
