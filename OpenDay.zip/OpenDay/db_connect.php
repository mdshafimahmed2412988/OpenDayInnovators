<?php
// Database connection settings
$servername = "localhost";
$username = "root";
$password = "";            // XAMPP default password is empty
$dbname = "open_day_app";  // your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
