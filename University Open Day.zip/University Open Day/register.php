<?php
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    //Database Connection
    $conn = new mysqli('localhost','root','','openday');
    if($conn->connect_error){
        die('Connection Failed  :  '. $conn->connect_error);
    }else{
        $stmt = $conn->prepare("Insert into registration(name, email, password)
                values(?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $password);
        $stmt->execute();
        echo "<script>alert('Registration Successful! You can now login.'); window.location.href='login.html';</script>";
        $stmt->close();
        $conn->close();
}


?>